RewriteEngine On
RewriteCond %{REQUEST_URI} !^/wp-admin [NC]
RewriteRule ^(.*)$ https://bangaloremedicalcoaching.com/ [R=301,L]